import React, { useState, useEffect } from 'react';

function App() {
  const [toastMessage, setToastMessage] = useState('');
  
  // Toast notifications helper
  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage('');
    }, 3000);
  };

  // ----------------------------------------------------
  // Project 1 States: SQL Sandbox
  // ----------------------------------------------------
  const [sqlQueryType, setSqlQueryType] = useState('slow');
  const [sqlResults, setSqlResults] = useState(null);
  const [sqlIsRunning, setSqlIsRunning] = useState(false);
  const [sqlTab, setSqlTab] = useState('preview'); // 'preview' | 'code'

  const sqlData = {
    slow: {
      query: `SELECT users.name, orders.amount, orders.created_at \nFROM users \nJOIN orders ON users.id = orders.user_id \nWHERE orders.amount > 850;`,
      code: `// Laravel Controller: Query Tanpa Indexing (Lambat)
public function getHighValueOrders()
{
    // Tanpa index pada kolom 'amount', query ini memicu full-table scan pada 10.000+ data
    return User::join('orders', 'users.id', '=', 'orders.user_id')
        ->where('orders.amount', '>', 850)
        ->select('users.name', 'orders.amount', 'orders.created_at')
        ->get();
}`,
      results: [
        { name: 'Ahmad Fauzi', amount: 'Rp 920.000', created_at: '2026-07-10' },
        { name: 'Siti Aminah', amount: 'Rp 880.000', created_at: '2026-07-11' }
      ],
      time: '184 ms',
      scanned: '10.240 baris (Full Table Scan)',
      explanation: '⚠️ Query memicu full-table scan karena kolom `orders.amount` tidak memiliki index. Waktu eksekusi lambat untuk dataset besar.'
    },
    optimized: {
      query: `SELECT users.name, orders.amount, orders.created_at \nFROM users \nJOIN orders USE INDEX (idx_amount) ON users.id = orders.user_id \nWHERE orders.amount > 850;`,
      code: `// Migration File (Menambahkan Index)
Schema::table('orders', function (Blueprint $table) {
    $table->index('amount', 'idx_amount');
});

// Laravel Controller: Query Teroptimasi (Cepat)
public function getHighValueOrdersOptimized()
{
    // Menggunakan index 'idx_amount', query langsung mencari baris data yang cocok
    return User::join('orders', 'users.id', '=', 'orders.user_id')
        ->where('orders.amount', '>', 850)
        ->select('users.name', 'orders.amount', 'orders.created_at')
        ->get();
}`,
      results: [
        { name: 'Ahmad Fauzi', amount: 'Rp 920.000', created_at: '2026-07-10' },
        { name: 'Siti Aminah', amount: 'Rp 880.000', created_at: '2026-07-11' }
      ],
      time: '4 ms',
      scanned: '2 baris (Index Scan)',
      explanation: '✅ Optimal! Database menggunakan Index `idx_amount` untuk langsung melompat ke baris data yang bernilai > 850. Kecepatan meningkat 46x lipat!'
    }
  };

  const handleRunSQL = () => {
    setSqlIsRunning(true);
    setSqlResults(null);
    setTimeout(() => {
      setSqlResults(sqlData[sqlQueryType]);
      setSqlIsRunning(false);
      showToast(`SQL Query dijalankan dalam ${sqlData[sqlQueryType].time}!`);
    }, 6000);
  };

  // ----------------------------------------------------
  // Project 2 States: Kanban Livewire Simulation
  // ----------------------------------------------------
  const [kanbanTasks, setKanbanTasks] = useState([
    { id: 1, text: 'Integrasi Midtrans Payment Gateway', status: 'todo' },
    { id: 2, text: 'Optimasi query laporan bulanan', status: 'done' },
    { id: 3, text: 'Membuat modul ekspor Excel', status: 'todo' }
  ]);
  const [newTaskText, setNewTaskText] = useState('');
  const [kanbanTab, setKanbanTab] = useState('preview'); // 'preview' | 'code'

  const livewireCode = `<!-- task-manager.blade.php (Livewire Component View) -->
<div class="kanban-board">
    <div class="column">
        <h3>To Do</h3>
        @foreach($tasks->where('status', 'todo') as $task)
            <div class="task-card">
                {{ $task->text }}
                <button wire:click="markAsDone({{ $task->id }})">✔</button>
            </div>
        @endforeach
    </div>
    
    <div class="column">
        <h3>Done</h3>
        @foreach($tasks->where('status', 'done') as $task)
            <div class="task-card">
                {{ $task->text }}
            </div>
        @endforeach
    </div>
    
    <form wire:submit.prevent="addTask">
        <input wire:model="newTaskText" type="text">
        <button type="submit">Tambah Task</button>
    </form>
</div>`;

  const handleAddKanbanTask = (e) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;
    const newTask = {
      id: Date.now(),
      text: newTaskText,
      status: 'todo'
    };
    setKanbanTasks([...kanbanTasks, newTask]);
    setNewTaskText('');
    showToast('Task ditambahkan via simulator Livewire (State terupdate)!');
  };

  const handleMoveKanbanTask = (id, newStatus) => {
    setKanbanTasks(kanbanTasks.map(t => t.id === id ? { ...t, status: newStatus } : t));
    showToast('Status task diperbarui secara real-time!');
  };

  // ----------------------------------------------------
  // Project 3 States: API Playground
  // ----------------------------------------------------
  const [apiEndpoint, setApiEndpoint] = useState('GET_PROJECTS');
  const [apiPayload, setApiPayload] = useState({ title: 'Sistem Inventory', tech: 'Laravel, MySQL' });
  const [apiResponse, setApiResponse] = useState(null);
  const [apiIsLoading, setApiIsLoading] = useState(false);
  const [apiTab, setApiTab] = useState('preview'); // 'preview' | 'code'

  const apiEndpointsDetails = {
    GET_PROJECTS: {
      route: `Route::get('/api/v1/projects', [ProjectController::class, 'index']);`,
      controller: `// ProjectController.php
public function index()
{
    // Mengambil seluruh proyek dan mengembalikan respon JSON terformat
    $projects = Project::all();
    return response()->json([
        'status' => 'success',
        'code' => 200,
        'data' => $projects
    ], 200);
}`,
      mockResponse: {
        status: 'success',
        code: 200,
        data: [
          { id: 1, title: 'E-Commerce App', tech: 'Laravel, React' },
          { id: 2, title: 'HRM Dashboard', tech: 'Laravel, Livewire' }
        ]
      }
    },
    POST_PROJECT: {
      route: `Route::post('/api/v1/projects', [ProjectController::class, 'store']);`,
      controller: `// ProjectController.php
public function store(Request $request)
{
    // Validasi data input
    $validated = $request->validate([
        'title' => 'required|string|max:255',
        'tech' => 'required|string'
    ]);

    // Membuat entry baru di database
    $project = Project::create($validated);
    
    return response()->json([
        'status' => 'created',
        'code' => 201,
        'message' => 'Proyek berhasil dibuat!',
        'data' => $project
      ], 201);
}`,
      mockResponse: {
        status: 'created',
        code: 201,
        message: 'Proyek berhasil dibuat!',
        data: {
          id: 3,
          title: '[Dynamic Title]',
          tech: '[Dynamic Tech]'
        }
      }
    }
  };

  const handleSendAPI = () => {
    setApiIsLoading(true);
    setApiResponse(null);
    
    setTimeout(() => {
      const details = apiEndpointsDetails[apiEndpoint];
      let response = { ...details.mockResponse };
      
      if (apiEndpoint === 'POST_PROJECT') {
        response.data = {
          id: Math.floor(Math.random() * 100) + 10,
          title: apiPayload.title || 'Sistem Tanpa Nama',
          tech: apiPayload.tech || 'Laravel'
        };
      }
      
      setApiResponse(response);
      setApiIsLoading(false);
      showToast(`API Response: ${response.code} ${apiEndpoint === 'POST_PROJECT' ? 'Created' : 'OK'}`);
    }, 800);
  };

  // Copy email to clipboard helper
  const handleCopyEmail = () => {
    navigator.clipboard.writeText('developer@email.com');
    showToast('Alamat email disalin ke clipboard!');
  };

  return (
    <div className="app-container">
      {/* Background Blobs */}
      <div className="glow-orb glow-orb-1"></div>
      <div className="glow-orb glow-orb-2"></div>
      <div className="glow-orb glow-orb-3"></div>

      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-logo">
          👨‍💻 DevPortfolio
        </div>
        <div className="nav-badge">
          Laravel Developer
        </div>
      </nav>

      {/* Hero Section */}
      <header className="hero-section">
        <div className="hero-content">
          <span className="hero-subtitle">Halo, Saya</span>
          <h1>
            Rian Hardianto <br />
            <span className="gradient">Full-Stack Developer</span>
          </h1>
          <p className="hero-about">
            Developer web berpengalaman selama 3+ tahun dengan spesialisasi Backend **Laravel** dan Frontend **ReactJS** (Inertia.js). Berfokus pada penulisan kode terstruktur, arsitektur database performa tinggi, integrasi API, dan optimalisasi query SQL.
          </p>
          <div className="hero-actions">
            <a href="#projects" className="btn btn-primary">Lihat Project & Live Preview</a>
            <a href="#contact" className="btn btn-secondary">Hubungi Saya</a>
          </div>
        </div>

        <div className="hero-avatar-container">
          <div className="avatar-glow"></div>
          <div className="avatar-wrapper">
            <img src="/avatar.png" alt="Rian Hardianto Avatar" className="avatar-image" />
          </div>
        </div>
      </header>

      {/* Tech Stack Section */}
      <section className="tech-section">
        <div className="section-title">
          <h2>Teknologi Unggulan</h2>
          <p>Daftar stack dan tools yang biasa saya gunakan untuk memecahkan masalah klien</p>
        </div>

        <div className="tech-grid">
          <div className="tech-badge"><span className="tech-icon">🐘</span> PHP</div>
          <div className="tech-badge"><span className="tech-icon">🔥</span> Laravel</div>
          <div className="tech-badge"><span className="tech-icon">⚛️</span> ReactJS</div>
          <div className="tech-badge"><span className="tech-icon">⚡</span> Inertia.js</div>
          <div className="tech-badge"><span className="tech-icon">🧬</span> Livewire</div>
          <div className="tech-badge"><span className="tech-icon">🏔️</span> Alpine.js</div>
          <div className="tech-badge"><span className="tech-icon">🐬</span> MySQL / PostgreSQL</div>
          <div className="tech-badge"><span className="tech-icon">🎨</span> Tailwind CSS</div>
          <div className="tech-badge"><span className="tech-icon">🐙</span> Git & GitHub</div>
          <div className="tech-badge"><span className="tech-icon">🐳</span> Docker</div>
          <div className="tech-badge"><span className="tech-icon">🔌</span> RESTful API</div>
          <div className="tech-badge"><span className="tech-icon">🚀</span> Redis Cache</div>
        </div>
      </section>

      {/* Projects Showcase Section */}
      <section className="projects-section" id="projects">
        <div className="section-title">
          <h2>Proyek Portofolio & Live Preview</h2>
          <p>Klik tab preview di sebelah kanan untuk mencoba fitur utama secara interaktif</p>
        </div>

        {/* Project 1: SQL Optimization Playground */}
        <div className="project-card">
          <div className="project-info">
            <div>
              <span className="project-tag">Backend & Database Optimization</span>
              <h3 className="project-title">Database Query & Indexing Tuner</h3>
              <p className="project-description">
                Modul simulasi optimasi database untuk membuktikan pentingnya Indexing. Membandingkan kecepatan eksekusi query standard (slow) dengan query teroptimasi (optimized) yang menggunakan SQL indexing langsung pada ribuan data.
              </p>
              <div className="project-tech-list">
                <span className="project-tech-tag">Laravel</span>
                <span className="project-tech-tag">MySQL</span>
                <span className="project-tech-tag">EXPLAIN query</span>
                <span className="project-tech-tag">Indexing</span>
              </div>
            </div>
            <div className="project-links">
              <button 
                className={`btn btn-secondary ${sqlTab === 'preview' ? 'active' : ''}`}
                onClick={() => setSqlTab('preview')}
                style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}
              >
                🎮 Sandbox Preview
              </button>
              <button 
                className={`btn btn-secondary ${sqlTab === 'code' ? 'active' : ''}`}
                onClick={() => setSqlTab('code')}
                style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}
              >
                💻 Lihat Kode Controller
              </button>
            </div>
          </div>

          {/* SQL Simulator Box */}
          <div className="sandbox-container">
            <div className="sandbox-header">
              <div className="window-dots">
                <span className="dot dot-red"></span>
                <span className="dot dot-yellow"></span>
                <span className="dot dot-green"></span>
              </div>
              <span style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-secondary)' }}>
                {sqlTab === 'preview' ? 'sql_sandbox_simulation.sql' : 'HighValueOrderController.php'}
              </span>
            </div>

            <div className="sandbox-workspace">
              {sqlTab === 'preview' ? (
                <>
                  <div className="sandbox-controls">
                    <div className="sql-input-row">
                      <select 
                        className="sql-selector" 
                        value={sqlQueryType}
                        onChange={(e) => setSqlQueryType(e.target.value)}
                      >
                        <option value="slow">Pilih Query: Standard / Tanpa Index (Lambat)</option>
                        <option value="optimized">Pilih Query: Teroptimasi / Dengan Index (Cepat)</option>
                      </select>
                    </div>
                    <button className="btn-send" onClick={handleRunSQL} disabled={sqlIsRunning}>
                      {sqlIsRunning ? '⏳ Menghitung...' : '▶ Run SQL'}
                    </button>
                  </div>
                  <div className="sandbox-body">
                    <pre className="code-viewer" style={{ color: '#F8FAFC', background: '#0F172A', padding: '0.75rem', borderRadius: '8px', border: '1px solid #1E293B', marginBottom: '0.75rem' }}>
                      {sqlData[sqlQueryType].query}
                    </pre>

                    {sqlIsRunning && (
                      <div style={{ textAlign: 'center', padding: '1.5rem', color: 'var(--neon-cyan)', fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}>
                        Database sedang memindai ribuan data tabel order...
                      </div>
                    )}

                    {sqlResults && !sqlIsRunning && (
                      <div>
                        <div style={{ display: 'flex', gap: '1rem', marginBottom: '0.5rem', fontSize: '0.8rem', fontFamily: 'var(--font-mono)' }}>
                          <div>⏱️ Kecepatan: <strong style={{ color: sqlQueryType === 'optimized' ? 'var(--neon-emerald)' : '#F59E0B' }}>{sqlResults.time}</strong></div>
                          <div>🔍 Baris Dipindai: <strong>{sqlResults.scanned}</strong></div>
                        </div>
                        <table className="sql-table">
                          <thead>
                            <tr>
                              <th>Nama Pengguna</th>
                              <th>Jumlah Pembelian</th>
                              <th>Tanggal Order</th>
                            </tr>
                          </thead>
                          <tbody>
                            {sqlResults.results.map((row, idx) => (
                              <tr key={idx}>
                                <td>{row.name}</td>
                                <td>{row.amount}</td>
                                <td>{row.created_at}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        <div className="sql-explain-box" style={{ borderColor: sqlQueryType === 'optimized' ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.3)', color: sqlQueryType === 'optimized' ? '#A7F3D0' : '#FDE68A' }}>
                          {sqlResults.explanation}
                        </div>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className="sandbox-body" style={{ background: '#0D1117' }}>
                  <pre className="code-viewer">
                    {sqlData[sqlQueryType].code}
                  </pre>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Project 2: Livewire Kanban Board Simulator */}
        <div className="project-card">
          <div className="project-info">
            <div>
              <span className="project-tag">Full-Stack Simulation</span>
              <h3 className="project-title">Laravel Livewire Task Manager</h3>
              <p className="project-description">
                Sebuah simulasi interaktif yang memperagakan bagaimana komponen reaktif **Laravel Livewire & Alpine.js** bekerja tanpa me-refresh seluruh halaman browser. Anda dapat menambahkan tugas dan memindahkannya secara instan.
              </p>
              <div className="project-tech-list">
                <span className="project-tech-tag">Laravel</span>
                <span className="project-tech-tag">Livewire</span>
                <span className="project-tech-tag">Alpine.js</span>
                <span className="project-tech-tag">Reactive DOM</span>
              </div>
            </div>
            <div className="project-links">
              <button 
                className={`btn btn-secondary ${kanbanTab === 'preview' ? 'active' : ''}`}
                onClick={() => setKanbanTab('preview')}
                style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}
              >
                🎮 Sandbox Preview
              </button>
              <button 
                className={`btn btn-secondary ${kanbanTab === 'code' ? 'active' : ''}`}
                onClick={() => setKanbanTab('code')}
                style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}
              >
                💻 Lihat Blade View
              </button>
            </div>
          </div>

          {/* Kanban Simulator Box */}
          <div className="sandbox-container">
            <div className="sandbox-header">
              <div className="window-dots">
                <span className="dot dot-red"></span>
                <span className="dot dot-yellow"></span>
                <span className="dot dot-green"></span>
              </div>
              <span style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-secondary)' }}>
                {kanbanTab === 'preview' ? 'livewire_task_dashboard.html' : 'task-manager.blade.php'}
              </span>
            </div>

            <div className="sandbox-workspace">
              {kanbanTab === 'preview' ? (
                <div className="sandbox-body" style={{ display: 'flex', flexDirection: 'column', height: '100%', padding: '0.75rem' }}>
                  <div className="kanban-board" style={{ marginBottom: '0.75rem', flex: 1 }}>
                    <div className="kanban-col">
                      <h4>To Do <span>{kanbanTasks.filter(t => t.status === 'todo').length}</span></h4>
                      <div className="kanban-tasks">
                        {kanbanTasks.filter(t => t.status === 'todo').map(task => (
                          <div className="kanban-card" key={task.id}>
                            <span>{task.text}</span>
                            <button className="kanban-card-btn" onClick={() => handleMoveKanbanTask(task.id, 'done')} title="Pindahkan ke Done">
                              ✔
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="kanban-col">
                      <h4>Done <span>{kanbanTasks.filter(t => t.status === 'done').length}</span></h4>
                      <div className="kanban-tasks">
                        {kanbanTasks.filter(t => t.status === 'done').map(task => (
                          <div className="kanban-card" key={task.id} style={{ borderColor: 'rgba(16, 185, 129, 0.2)', opacity: 0.8 }}>
                            <span style={{ textDecoration: 'line-through', color: 'var(--text-secondary)' }}>{task.text}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <form onSubmit={handleAddKanbanTask} className="kanban-add-input">
                    <input 
                      type="text" 
                      placeholder="Tulis nama task baru..." 
                      className="kanban-input"
                      value={newTaskText}
                      onChange={(e) => setNewTaskText(e.target.value)}
                    />
                    <button type="submit" className="kanban-add-btn">
                      + Tambah
                    </button>
                  </form>
                </div>
              ) : (
                <div className="sandbox-body">
                  <pre className="code-viewer">
                    {livewireCode}
                  </pre>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Project 3: API Playground */}
        <div className="project-card">
          <div className="project-info">
            <div>
              <span className="project-tag">API Integration & Security</span>
              <h3 className="project-title">RESTful API Endpoint Tester</h3>
              <p className="project-description">
                Interactive API Playground untuk mempraktikkan bagaimana RESTful API di Laravel dibangun. Anda dapat mensimulasikan permintaan `GET` untuk mengambil proyek, atau mengirimkan data `POST` baru ke server bayangan.
              </p>
              <div className="project-tech-list">
                <span className="project-tech-tag">Laravel Route</span>
                <span className="project-tech-tag">REST API</span>
                <span className="project-tech-tag">JSON Response</span>
                <span className="project-tech-tag">Validation</span>
              </div>
            </div>
            <div className="project-links">
              <button 
                className={`btn btn-secondary ${apiTab === 'preview' ? 'active' : ''}`}
                onClick={() => setApiTab('preview')}
                style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}
              >
                🎮 Sandbox Preview
              </button>
              <button 
                className={`btn btn-secondary ${apiTab === 'code' ? 'active' : ''}`}
                onClick={() => setApiTab('code')}
                style={{ padding: '0.5rem 1rem', fontSize: '0.85rem' }}
              >
                💻 Lihat Controller PHP
              </button>
            </div>
          </div>

          {/* API Playground Box */}
          <div className="sandbox-container">
            <div className="sandbox-header">
              <div className="window-dots">
                <span className="dot dot-red"></span>
                <span className="dot dot-yellow"></span>
                <span className="dot dot-green"></span>
              </div>
              <span style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--text-secondary)' }}>
                {apiTab === 'preview' ? 'api_request_playground.json' : 'ProjectController.php'}
              </span>
            </div>

            <div className="sandbox-workspace">
              {apiTab === 'preview' ? (
                <>
                  <div className="sandbox-controls">
                    <select 
                      className="api-selector"
                      value={apiEndpoint}
                      onChange={(e) => {
                        setApiEndpoint(e.target.value);
                        setApiResponse(null);
                      }}
                    >
                      <option value="GET_PROJECTS">GET /api/v1/projects (Ambil Data)</option>
                      <option value="POST_PROJECT">POST /api/v1/projects (Buat Data Baru)</option>
                    </select>
                    <button className="btn-send" onClick={handleSendAPI} disabled={apiIsLoading}>
                      {apiIsLoading ? '⏳ Mengirim...' : '⚡ Send Request'}
                    </button>
                  </div>
                  <div className="sandbox-body" style={{ display: 'flex', flexDirection: 'column', height: '100%', padding: '0.75rem' }}>
                    {apiEndpoint === 'POST_PROJECT' && (
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', marginBottom: '0.5rem' }}>
                        <div>
                          <label style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', display: 'block', marginBottom: '0.2rem' }}>Nama Proyek:</label>
                          <input 
                            type="text" 
                            className="kanban-input" 
                            style={{ width: '100%' }}
                            value={apiPayload.title}
                            onChange={(e) => setApiPayload({ ...apiPayload, title: e.target.value })}
                          />
                        </div>
                        <div>
                          <label style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', display: 'block', marginBottom: '0.2rem' }}>Teknologi:</label>
                          <input 
                            type="text" 
                            className="kanban-input" 
                            style={{ width: '100%' }}
                            value={apiPayload.tech}
                            onChange={(e) => setApiPayload({ ...apiPayload, tech: e.target.value })}
                          />
                        </div>
                      </div>
                    )}

                    <div className="api-response-panel">
                      <div className="response-badge" style={{ display: apiIsLoading ? 'none' : 'block' }}>
                        {apiResponse ? `${apiResponse.code} Response` : '200 Idle'}
                      </div>
                      
                      {apiIsLoading ? (
                        <pre className="code-viewer" style={{ color: 'var(--neon-cyan)' }}>
                          Memproses request Laravel Route Controller...
                        </pre>
                      ) : apiResponse ? (
                        <pre className="code-viewer" style={{ color: '#34D399' }}>
                          {JSON.stringify(apiResponse, null, 2)}
                        </pre>
                      ) : (
                        <pre className="code-viewer" style={{ color: 'var(--text-secondary)' }}>
                          {`// Kirim request untuk melihat Respon API dari route Laravel\nRoute: ${apiEndpointsDetails[apiEndpoint].route}`}
                        </pre>
                      )}
                    </div>
                  </div>
                </>
              ) : (
                <div className="sandbox-body">
                  <pre className="code-viewer">
                    {apiEndpointsDetails[apiEndpoint].controller}
                  </pre>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer & Contacts Section */}
      <footer className="footer" id="contact">
        <div className="footer-content">
          <div className="footer-logo">Rian Hardianto</div>
          <p className="footer-tagline">
            Mari bekerjasama membangun aplikasi backend yang tangguh, sistem API yang aman, dan antarmuka web interaktif yang modern.
          </p>

          <div className="contacts-grid">
            <a href="https://github.com" target="_blank" rel="noreferrer" className="contact-card">
              <span className="contact-icon">🐙</span> GitHub
            </a>
            <button onClick={handleCopyEmail} className="contact-card">
              <span className="contact-icon">✉️</span> developer@email.com
            </button>
            <a href="https://wa.me/628123456789" target="_blank" rel="noreferrer" className="contact-card">
              <span className="contact-icon">💬</span> WhatsApp (Contact)
            </a>
          </div>

          <p className="footer-credit">
            &copy; 2026 Rian Hardianto. Dibuat menggunakan ReactJS & Vanilla CSS (Vite).
          </p>
        </div>
      </footer>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="copy-toast">
          {toastMessage}
        </div>
      )}
    </div>
  );
}

export default App;
